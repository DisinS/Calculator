﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Collections;

namespace Kalkulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            NumberFormatInfo nfi = new NumberFormatInfo(); //kultury języka sprawdzić
            nfi.NumberDecimalSeparator = ","; 
            InitializeComponent();
        }
        private List<char> znaki = new List<char>() { '+', '-', '*', '/', '^', '!', '=', '(', ')' };
        private List<char> cyfry = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '∞' };


        #region Cyfry
        private void button0_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("0");
        }
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("1");
        }
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("2");
        }
        private void button3_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("3");
        }
        private void button4_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("4");
        }
        private void button5_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("5");
        }
        private void button6_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("6");
        }
        private void button7_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("7");
        }
        private void button8_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("8");
        }
        private void button9_Click(object sender, RoutedEventArgs e)
        {
            dopisanie("9");
        }
        #endregion

        #region Znaki
        private void buttonprzecinek_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku(",");
        }
        private void buttonplus_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("+");
        }
        private void buttonminus_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("-");
        }
        private void buttonmnozenie_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("*");
        }
        private void buttondzielenie_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("/");
        }
        private void buttonpotega_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("^");
        }
        private void buttonsilnia_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("!");
        }
        private void buttonNOtwarty_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku("(");
        }
        private void buttonNTyl_Click(object sender, RoutedEventArgs e)
        {
            dopisanieznaku(")");
        }
#endregion
        
        #region Funkcje
        private void buttonwynik_Click(object sender, RoutedEventArgs e)
        {
            string rownanie = Wyswietlacz.Content.ToString();
            if (rownanie.Length > 0 && rownanie.Contains("+") || rownanie.Contains("-") || rownanie.Contains("*") || rownanie.Contains("/") || rownanie.Contains("^") || rownanie.Contains("!"))
            {
                if (cyfry.Contains(rownanie.Last()) || rownanie.EndsWith(")") || rownanie.EndsWith("!"))
                {
                    string zapisONP = notacjaodwrocona(rownanie);
                    Stack wynik = new Stack();
                    string tresc = "";

                    for (int i = 0; i < zapisONP.Length; i++)
                    {
                        if (zapisONP[i].ToString().Equals(",") || cyfry.Contains(zapisONP[i]))
                        {
                            tresc += zapisONP[i];
                        }
                        else if (zapisONP[i].ToString().Equals(" ") && !tresc.Equals(""))
                        {
                            wynik.Push(tresc);
                            tresc = "";
                        }
                        else if (znaki.Contains(zapisONP[i]))
                        {
                            if (zapisONP[i].ToString().Equals("+"))
                            {
                                double szczyt = dodawanie(Convert.ToDouble(wynik.Pop()), Convert.ToDouble(wynik.Pop()));
                                wynik.Push(szczyt);
                            }
                            else if (zapisONP[i].ToString().Equals("-"))
                            {
                                try
                                {
                                    double szczyt = odejmowanie(Convert.ToDouble(wynik.Pop()), Convert.ToDouble(wynik.Pop()));
                                    wynik.Push(szczyt);
                                }
                                catch (System.InvalidOperationException)
                                {
                                    Wyswietlacz.Content = "Kalkulator nie wykonuje działań na liczbach ujemnych.";
                                }
                            }
                            else if (zapisONP[i].ToString().Equals("*"))
                            {
                                double szczyt = mnozenie(Convert.ToDouble(wynik.Pop()), Convert.ToDouble(wynik.Pop()));
                                wynik.Push(szczyt);
                            }
                            else if (zapisONP[i].ToString().Equals("/"))
                            {
                                if (Convert.ToDouble(wynik.Peek()) == 0)
                                {
                                    Wyswietlacz.Content = "Nie wolno dzielić przez 0!";
                                    break;
                                }
                                double szczyt = dzielenie(Convert.ToDouble(wynik.Pop()), Convert.ToDouble(wynik.Pop()));
                                wynik.Push(szczyt);
                            }
                            else if (zapisONP[i].ToString().Equals("^"))
                            {
                                double szczyt = potega(Convert.ToDouble(wynik.Pop()), Convert.ToDouble(wynik.Pop()));
                                wynik.Push(szczyt);
                            }
                            else if (zapisONP[i].ToString().Equals("!"))
                            {
                                double szczyt = silnia(Convert.ToDouble(wynik.Pop()));
                                wynik.Push(szczyt);
                            }
                        }
                    }
                    if (!Wyswietlacz.Content.Equals("Nie wolno dzielić przez 0!") && !Wyswietlacz.Content.Equals("Kalkulator nie wykonuje działań na liczbach ujemnych."))
                    {
                        Wyswietlacz.Content = wynik.Peek();
                        Wyswietlacz.FontSize = 24;
                    }
                }
            }            
        }
        private void buttonusun_Click(object sender, RoutedEventArgs e)
        {
            string wyswietlacz = Wyswietlacz.Content.ToString();
            int dlugosc = wyswietlacz.Length;
            if(dlugosc != 0)
            {
                Wyswietlacz.Content = wyswietlacz.Remove(dlugosc - 1);
            }
        }
        private void buttonC_Click(object sender, RoutedEventArgs e)
        {
            Wyswietlacz.Content = "";
        }
        private void dopisanie(string znak)
        {
            string wyswietlacz = Wyswietlacz.Content.ToString();
            if (wyswietlacz.Length > 24) 
            {
                Wyswietlacz.FontSize = 576 / wyswietlacz.Length;                
            }
            if (!wyswietlacz.EndsWith("!"))
            {
                Wyswietlacz.Content = wyswietlacz + znak;
            }
            if (wyswietlacz.EndsWith(")"))
            {
                Wyswietlacz.Content = wyswietlacz;
            }
            if (Wyswietlacz.FontSize < 8)
            {
                Wyswietlacz.FontSize = 24;
                Wyswietlacz.Content = "Obraz nieczytelny";
            }
            /*if(wyswietlacz.EndsWith("0") && !wyswietlacz.Contains(",")) // 0,0003 + 0000000 5000
            {
                Wyświetlacz.Content = wyswietlacz;
            }*/
        }
        private int liczniknawiasow = 0;
        private void dopisanieznaku(string znak)
        {
            string wyswietlacz =  Wyswietlacz.Content.ToString();
            int dlugosc = wyswietlacz.Length;
            
            
            if (dlugosc != 0)
            {
                if (wyswietlacz.EndsWith("+") || wyswietlacz.EndsWith("-") || wyswietlacz.EndsWith("*") || wyswietlacz.EndsWith("/") || wyswietlacz.EndsWith("^") || wyswietlacz.EndsWith(","))
                {
                    Wyswietlacz.Content = wyswietlacz;
                    if(!wyswietlacz.EndsWith(",") && znak.Equals("("))
                    {
                        Wyswietlacz.Content = wyswietlacz + znak;
                        liczniknawiasow++;
                    }
                }
                else if (wyswietlacz.EndsWith("!") && znak.Equals(","))
                {
                    Wyswietlacz.Content = wyswietlacz;
                }
                else if (wyswietlacz.EndsWith("!") && znak.Equals("("))
                {
                    Wyswietlacz.Content = wyswietlacz;
                }
                else if (wyswietlacz.EndsWith("(") && !znak.Equals("(")) 
                {
                    Wyswietlacz.Content = wyswietlacz;
                }
                else if (cyfry.Contains(wyswietlacz.Last()) && znak.Equals("("))  
                {
                    Wyswietlacz.Content = wyswietlacz;
                }
                else if(wyswietlacz.EndsWith(")") && znak.Equals("("))
                {
                    Wyswietlacz.Content = wyswietlacz;
                }
                else
                {
                    if (!znak.Equals(")"))
                    {
                        Wyswietlacz.Content = wyswietlacz + znak;
                        if (znak.Equals("("))
                        {
                            liczniknawiasow++;
                        }
                    }
                    else if (znak.Equals(")") && liczniknawiasow > 0)
                    {
                        Wyswietlacz.Content = wyswietlacz + znak;
                        liczniknawiasow--;
                    }
                }
            }
            else
            {
                if (znak.Equals("("))
                {
                    Wyswietlacz.Content = wyswietlacz + znak;
                    liczniknawiasow++;
                }
            }
        }
        private string notacjaodwrocona(string rownanie)
        {
            List<string> wyjscie = new List<string>();
            List<char> stos = new List<char>();
            /*List<char> znaki = new List<char>();
            znaki.Add('+');
            znaki.Add('-');
            znaki.Add('*');
            znaki.Add('/');
            znaki.Add('^');
            znaki.Add('!');
            znaki.Add('=');
            znaki.Add('(');
            znaki.Add(')');*/

            char obecny;
            int wartoscpoprzednia = 0;
            int wartosc = 0;
            for (int i = 0; i < rownanie.Length; i++)
            {
                obecny = rownanie[i];
                if (!znaki.Contains(obecny))
                {
                    wyjscie.Add(obecny.ToString());
                }
                else
                {
                    wyjscie.Add(" ");
                    wartosc = priorytet(obecny);
                    if (stos.Count() != 0)
                    {
                        wartoscpoprzednia = priorytet(stos.Last());
                    }

                    if (stos.Count() == 0)
                    {
                        stos.Add(obecny);
                    }
                    else if (obecny.ToString().Equals("("))
                    {
                        stos.Add(obecny);
                    }
                    else if (obecny.ToString().Equals(")"))
                    {
                        while (!stos.Last().ToString().Equals("("))
                        {
                            wyjscie.Add(stos.Last().ToString());
                            stos.RemoveAt(stos.Count() - 1);
                        }
                        stos.RemoveAt(stos.Count() - 1);
                    }
                    else if (wartosc > wartoscpoprzednia)
                    {
                        stos.Add(obecny);
                    }
                    else
                    {
                        while (wartosc <= wartoscpoprzednia)
                        {
                            wyjscie.Add(stos.Last().ToString());
                            stos.RemoveAt(stos.Count() - 1);
                            if (stos.Count() == 0)
                            {
                                break;
                            }
                            wartoscpoprzednia = priorytet(stos.Last());
                        }
                        stos.Add(obecny);
                    }
                }
            }

            for (int i = stos.Count - 1; i >= 0; i--)
            {
                wyjscie.Add(" " + stos[i]);
            }
            string zapisONP = String.Concat(wyjscie);
            return zapisONP;
        }
        private int priorytet(char obecny)
        {
            int wartosc = -1;
            if (obecny == '(')
                wartosc = 0;
            else if (obecny == '=')
                wartosc = 1;
            else if (obecny == '+' || obecny == '-' || obecny == ')')
                wartosc = 2;
            else if (obecny == '*' || obecny == '/')
                wartosc = 3;
            else if (obecny == '^')
                wartosc = 4;
            else if (obecny == '!')
                wartosc = 5;
            return wartosc;
        }
        #endregion

        #region Działania
        private double dodawanie(double a, double b)
        {
            return b + a;
        }
        private double odejmowanie(double a, double b)
        {
            return b - a;
        }
        private double mnozenie(double a, double b)
        {
            return b * a;
        }
        private double dzielenie(double a, double b)
        {
            return b / a;
        }
        private double potega(double a, double b)
        {
            return Math.Pow(b, a);
        }
        private double silnia(double a)
        {
            int wynik = 1;
            for (int i = 1; i <= a; i++)
            {
                wynik *= i;
            }
            return wynik;
        }
        #endregion

        //warunek na znak w nawiasach
        //wpisanie 0, a nie 000000,
        //kolorki, interfejs
        //końcówka double 00000000004 dodaje dalej i podaje w wyniku
        //cyfra zamknięty nawias na końcu    OK
        //brak znaków   OK
        //stałe wymiary kalkulatora   OK
        //wyjatek na dzielenie przez 0   OK
        //za dużo cyfr to zmniejszenie (po dojściu do bandy)   OK
        //warunek na brak znaku   OK
        //minus z przodu po działaniu   OK



    }
}
